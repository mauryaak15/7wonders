export class Wonders {
    id: string;
    place: string;
    description?: string;
    imageURL: string;
    ratings: string;
    likes: number;
    flag = false;
  }
